Exercise 1

Kmeans
a) The result varies on random seed each run. Areas with very similar 
   color may be splitted to different cluster. Even if same regions are
   clustered, the label maybe swapped to a different number.

b) Run the algorithm several times and compare for most stable / often 
   occurring result. Use semantic information to set seeds into areas of 
   interest, e.g. sky, water, forest,...
