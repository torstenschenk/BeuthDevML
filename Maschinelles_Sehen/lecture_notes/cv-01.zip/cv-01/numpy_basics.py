import numpy as np


# A1. Numpy and Linear Algebra

